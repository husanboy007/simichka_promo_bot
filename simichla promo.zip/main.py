import logging
import os
import sqlite3
import random
import re
from aiogram import Bot, Dispatcher, types, executor
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove
from dotenv import load_dotenv
from db import init_db, check_code_status, save_participant
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

# .env yuklash
load_dotenv()
API_TOKEN = os.getenv("BOT_TOKEN")

# Adminlarni ro'yxat qilib olish (Bo'sh joylarni olib tashlaydi)
admin_env = os.getenv("ADMIN_IDS", "")
ADMIN_IDS = [int(i.strip()) for i in admin_env.split(",") if i.strip()]

logging.basicConfig(level=logging.INFO)
bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

user_temp_data = {}
user_states = {} # Murojaat holatini eslab qolish uchun
init_db()

# --- YANGI QO'SHILGAN QISM: Adminlarga xabar yuborish ---
async def on_startup_notify(dp: Dispatcher):
    for admin_id in ADMIN_IDS:
        try:
            await bot.send_message(
                admin_id, 
                "🚀 **Bot muvaffaqiyatli ishga tushdi!**\n\n"
                "✅ Hozirda bot 24/7 rejimda xizmat ko'rsatishga tayyor.",
                parse_mode="Markdown"
            )
        except Exception as e:
            logging.error(f"Admin {admin_id} ga xabar yuborishda xatolik: {e}")
# ------------------------------------------------------

# Asosiy menyu (Adminga murojaat tugmasi bilan)
def main_keyboard():
    kb = ReplyKeyboardMarkup(resize_keyboard=True)
    kb.add(KeyboardButton("👨‍💻 Adminga murojaat qilish"))
    return kb

def phone_keyboard():
    return ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True).add(
        KeyboardButton("📱 Telefon raqamni yuborish", request_contact=True)
    )

# --- 1. SAHIFALANGAN BARCHA KODLAR ---
@dp.message_handler(commands=['list_codes'])
async def list_promo_codes(message: types.Message):
    if message.from_user.id in ADMIN_IDS:
        args = message.get_args()
        page = int(args) if args.isnumeric() else 1
        limit = 50
        offset = (page - 1) * limit

        conn = sqlite3.connect('promo_codes.db')
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM codes")
        total_codes = cursor.fetchone()[0]
        cursor.execute("SELECT code, status FROM codes LIMIT ? OFFSET ?", (limit, offset))
        codes = cursor.fetchall()
        conn.close()

        if not codes:
            await message.answer("📭 Bu sahifada kodlar mavjud emas.")
            return

        total_pages = (total_codes + limit - 1) // limit
        text = f"📋 **Promokodlar ro'yxati (Sahifa {page}/{total_pages}):**\n\n"
        
        for code, status in codes:
            icon = "✅" if status == 'active' else "❌"
            text += f"{icon} `{code}` - {status}\n"
        
        # --- TUGMALARNI YARATISH ---
        kb = InlineKeyboardMarkup(row_width=2)
        buttons = []
        if page > 1:
            buttons.append(InlineKeyboardButton(text="⬅️ Orqaga", callback_data=f"list_page_{page-1}"))
        if page < total_pages:
            buttons.append(InlineKeyboardButton(text="Oldinga ➡️", callback_data=f"list_page_{page+1}"))
        
        kb.add(*buttons)
        # ---------------------------

        await message.answer(text, parse_mode="Markdown", reply_markup=kb)
    else:
        await message.answer("⚠️ Bu buyruq faqat admin uchun!")

# Tugmalar bosilganda sahifani yangilash uchun Handler
@dp.callback_query_handler(lambda c: c.data and c.data.startswith('list_page_'))
async def process_callback_list_page(callback_query: types.CallbackQuery):
    page = int(callback_query.data.split('_')[2])
    # Bu yerda yangi xabar yubormasdan, mavjudini tahrirlash (edit) mumkin
    # Lekin eng oson yo'li - buyruqni qayta chaqirish:
    message = callback_query.message
    message.text = f"/list_codes {page}"
    # Admin tekshiruvi uchun soxta message obyekti yaratib, funksiyani qayta bajaramiz
    from aiogram.utils.executor import start_polling
    await list_promo_codes(callback_query.message) 
    await callback_query.answer()

@dp.callback_query_handler(lambda c: c.data and c.data.startswith('list_page_'))
async def process_callback_list_page(callback_query: types.CallbackQuery):
    if callback_query.from_user.id in ADMIN_IDS:
        page = int(callback_query.data.split('_')[2])
        callback_query.message.text = f"/list_codes {page}"
        await list_promo_codes(callback_query.message)
        await callback_query.answer()
    else:
        await callback_query.answer("⚠️ Bu buyruq faqat admin uchun!", show_alert=True)
        
        # --- 2. FAQAT ISHLATILGAN KODLAR ---
@dp.message_handler(commands=['used_codes'])
async def list_used_codes(message: types.Message):
    if message.from_user.id in ADMIN_IDS:
        conn = sqlite3.connect('promo_codes.db')
        cursor = conn.cursor()
        cursor.execute("SELECT code FROM codes WHERE status = 'used'")
        used_codes = cursor.fetchall()
        conn.close()

        if not used_codes:
            await message.answer("📭 Hali ishlatilgan kodlar mavjud emas.")
            return

        text = f"❌ **Ishlatilgan kodlar ro'yxati ({len(used_codes)} ta):**\n\n"
        for code in used_codes:
            text += f"• `{code[0]}`\n"
        
        if len(text) > 4096:
            for x in range(0, len(text), 4096):
                await message.answer(text[x:x+4096], parse_mode="Markdown")
        else:
            await message.answer(text, parse_mode="Markdown")
@dp.message_handler(commands=['all_participants'])
async def show_all(message: types.Message):
    if message.from_user.id in ADMIN_IDS:
        conn = sqlite3.connect('promo_codes.db')
        cursor = conn.cursor()
        cursor.execute("SELECT username, phone, code FROM participants")
        rows = cursor.fetchall()
        conn.close()

        if rows:
            text = "👥 **Barcha ishtirokchilar:**\n\n"
            for r in rows:
                text += f"👤 Ism: {r[0]}\n"
                text += f"📞 Tel: {r[1]}\n"
                text += f"🎫 Kod: {r[2]}\n"
                text += "------------------------\n"
            
            if len(text) > 4096:
                for x in range(0, len(text), 4096):
                    await message.answer(text[x:x+4096])
            else:
                await message.answer(text)
        else:
            await message.answer("Hali ishtirokchilar yo'q.")             

@dp.message_handler(commands=['stats'])
async def get_stats(message: types.Message):
    if message.from_user.id in ADMIN_IDS:
        conn = sqlite3.connect('promo_codes.db')
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM codes WHERE status = 'active'")
        active_count = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM codes WHERE status = 'used'")
        used_count = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(DISTINCT user_id) FROM participants")
        participants_count = cursor.fetchone()[0]
        conn.close()

        stats_text = (
            "📊 **Bot Statistikasi:**\n\n"
            f"✅ Faol (ishlatilmagan) kodlar: {active_count} ta\n"
            f"❌ Ishlatilgan kodlar: {used_count} ta\n"
            f"👥 Jami ishtirokchilar: {participants_count} ta\n\n"
            f"💰 Jami muomaladagi kodlar: {active_count + used_count} ta"
        )
        await message.answer(stats_text, parse_mode="Markdown")
    else:
        await message.answer("⚠️ Bu buyruq faqat admin uchun!")

@dp.message_handler(commands=['start'])
async def start_handler(message: types.Message):
    await message.answer(
        f"Assalomu alaykum, {message.from_user.first_name}!\n\n"
        "😊 Simichka botiga xush kelibsiz. O'yinda qatnashish uchun "
        "avval telefon raqamingizni yuboring:",
        reply_markup=phone_keyboard()
    )

@dp.message_handler(commands=['draw'])
async def pick_winner(message: types.Message):
    if message.from_user.id in ADMIN_IDS:
        conn = sqlite3.connect('promo_codes.db')
        cursor = conn.cursor()
        cursor.execute("SELECT username, phone, code FROM participants")
        participants = cursor.fetchall()
        conn.close()


        if not participants:
            await message.answer("📭 Ishtirokchilar mavjud emas, g'olibni aniqlab bo'lmaydi.")
            return

        winner = random.choice(participants)
        winner_text = (
            "🎉 **G'olib aniqlandi!**\n\n"
            f"👤 Ism: {winner[0]}\n"
            f"📞 Tel: {winner[1]}\n"
            f"🎫 Omadli kod: `{winner[2]}`\n\n"
            "Tabriklaymiz!"
        )
        await message.answer(winner_text, parse_mode="Markdown")
    else:
        await message.answer("⚠️ Bu buyruq faqat admin uchun!")

# --- BARCHA FOYDALANUVCHILARGA XABAR YUBORISH ---
@dp.message_handler(commands=['reklama'])
async def broadcast_message(message: types.Message):
    if message.from_user.id in ADMIN_IDS:
        broadcast_text = message.get_args()
        
        if not broadcast_text:
            await message.answer("⚠️ Foydalanish: `/reklama xabar matni`")
            return

        conn = sqlite3.connect('promo_codes.db')
        cursor = conn.cursor()
        cursor.execute("SELECT DISTINCT user_id FROM participants")
        users = cursor.fetchall()
        conn.close()

        count = 0
        for user in users:
            try:
                await bot.send_message(user[0], broadcast_text)
                count += 1
            except Exception:
                continue

        await message.answer(f"✅ Xabar {count} ta foydalanuvchiga yuborildi!")
        
@dp.message_handler(commands=['clear_participants'])
async def clear_all_participants(message: types.Message):
    if message.from_user.id in ADMIN_IDS:
        conn = sqlite3.connect('promo_codes.db')
        cursor = conn.cursor()
        cursor.execute("DELETE FROM participants")
        conn.commit()
        conn.close()
        await message.answer("🗑 **Barcha ishtirokchilar ro'yxati o'chirildi!**")
    else:
        await message.answer("⚠️ Faqat admin uchun!")

# --- ADMINGA MUROJAAT QISMI ---
@dp.message_handler(lambda message: message.text == "👨‍💻 Adminga murojaat qilish")
async def start_murojaat(message: types.Message):
    user_states[message.from_user.id] = "waiting_for_murojaat"
    await message.answer("📝 Murojaatingizni yozib qoldiring:", reply_markup=ReplyKeyboardRemove())

@dp.message_handler(lambda message: message.from_user.id in ADMIN_IDS and message.reply_to_message)
async def admin_reply(message: types.Message):
    try:
        # Xabardan ID ni qidirib topish
        match = re.search(r"🆔:(\d+)", message.reply_to_message.text)
        if match:
            user_id = match.group(1)
            await bot.send_message(user_id, f"👨‍💻 **Admin javobi:**\n\n{message.text}", reply_markup=main_keyboard())
            await message.answer("✅ Javob yuborildi!")
    except Exception as e:
        await message.answer(f"❌ Xatolik: {e}")
# ------------------------------

@dp.message_handler(content_types=['contact'])
async def contact_handler(message: types.Message):
    user_temp_data[message.from_user.id] = message.contact.phone_number
    await message.answer(
        "✅ Raqamingiz qabul qilindi. Endi qadoq ichidagi 6 xonali kodni yuboring:\n"
        "Kodlar haftaning yakshanba kuni 16:00 gacha qabul qilinadi",
        reply_markup=main_keyboard()
    )

@dp.message_handler()
async def main_handler(message: types.Message):
    uid = message.from_user.id

    # Adminga xabar yuborish mantiqi
    if user_states.get(uid) == "waiting_for_murojaat":
        user_states[uid] = None
        phone = user_temp_data.get(uid, "Noma'lum")
        nick = f"@{message.from_user.username}" if message.from_user.username else "Niki yo'q"
        
        for admin_id in ADMIN_IDS:
            await bot.send_message(
                admin_id, 
                f"📩 **Yangi murojaat!**\n\n"
                f"👤 Ism: {message.from_user.full_name}\n"
                f"🌐 Nik: {nick}\n"
                f"📞 Tel: {phone}\n"
                f"💬 Xabar: {message.text}\n\n"
                f"👉 Javob berish uchun Reply qiling.\n🆔:{uid}"
            )
        await message.answer("✅ Xabaringiz adminga yuborildi.", reply_markup=main_keyboard())
        return

    # Kod tekshirish qismi
    if uid not in user_temp_data:
        await message.answer("Iltimos, avval telefon raqamingizni yuboring!", reply_markup=phone_keyboard())
        return

    code = message.text.upper().strip()
    status = check_code_status(code)

    if status == 'active':
        save_participant(uid, message.from_user.full_name, user_temp_data[uid], code)
        STIKER_ID = "CAACAgIAAxkBAAMlaUnxsZIrK2QGHcyDi1JMKXoI2JQAAqoYAAIPZQhKBszc59D9vtM2BA"
        try:
            await message.answer_sticker(STIKER_ID)
        except Exception:
            pass

        await message.answer(f"✅ Rahmat! {code} kodi qabul qilindi. Omad tilaymiz!", reply_markup=main_keyboard())
        info_text = (
            "Yakshanba kuni soat 20:00 da Instagram profilimizda "
            "[@Quqon_bozorida](https://instagram.com/Quqon_bozorida) jonli efirda g'olibni aniqlaymiz. "
            "Shu bot orqali g'olib sizlarga ham ma'lum qilinadi."
        )
        await message.answer(info_text, parse_mode="Markdown", disable_web_page_preview=False)
        
    elif status == 'used':
        await message.answer("❌ Bu kod allaqachon ishlatilgan!", reply_markup=main_keyboard())
    else:
        # Agar bu 6 xonali kod bo'lmasa va murojaat holatida bo'lmasa
        await message.answer("⚠️ Kod xato yoki mavjud emas!", reply_markup=main_keyboard())

import time

if __name__ == '__main__':
    # Botni ishga tushirish (avtomatik qayta yonmaydi)
    executor.start_polling(dp, skip_updates=True, on_startup=on_startup_notify)